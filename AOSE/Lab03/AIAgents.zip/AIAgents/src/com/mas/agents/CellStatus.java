package com.mas.agents;

public enum CellStatus {
	OPEN, OBSTACLE, EOL
}
