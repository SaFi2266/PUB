package com.mas.agents;

public enum Direction {
	NORTH, SOUTH, EAST, WEST
}
