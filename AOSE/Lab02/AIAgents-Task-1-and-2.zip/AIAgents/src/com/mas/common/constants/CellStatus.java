package com.mas.common.constants;

public enum CellStatus {
	OPEN, OBSTACLE, EOL
}
