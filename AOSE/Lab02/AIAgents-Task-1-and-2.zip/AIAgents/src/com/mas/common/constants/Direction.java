package com.mas.common.constants;

public enum Direction {
	NORTH, SOUTH, EAST, WEST
}
