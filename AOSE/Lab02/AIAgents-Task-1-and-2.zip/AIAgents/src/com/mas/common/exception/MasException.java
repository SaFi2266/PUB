package com.mas.common.exception;

public class MasException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2446891993092358303L;

	public MasException(String message) {
		super(message);
	}
}
