# ai_robot
Implementation of different tree search algorithms for a [vacuum cleaner world problem](http://web.ntnu.edu.tw/~tcchiang/ai/Vacuum%20Cleaner%20World.htm)
