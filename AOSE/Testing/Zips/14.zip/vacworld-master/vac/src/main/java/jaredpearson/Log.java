package jaredpearson;

public interface Log {
	public void debug(String message);
}