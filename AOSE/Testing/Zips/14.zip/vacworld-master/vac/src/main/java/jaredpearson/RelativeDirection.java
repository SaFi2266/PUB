package jaredpearson;

public enum RelativeDirection {
	LEFT,
	RIGHT
}