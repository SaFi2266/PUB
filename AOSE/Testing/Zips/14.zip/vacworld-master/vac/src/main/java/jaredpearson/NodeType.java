package jaredpearson;

public enum NodeType {
	UNKNOWN,
	OPEN,
	SOLID
}