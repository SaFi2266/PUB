[Documentation](https://goalapl.atlassian.net/wiki/display/ENV/Vacuum+World) for
the Vacuum World.
