package actions;

@SuppressWarnings("serial")
public class ImpossibleActionException extends Exception {

	public ImpossibleActionException(String message) {
		super(message);
	}

}
