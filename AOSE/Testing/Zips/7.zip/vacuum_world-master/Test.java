package world;

public class Test {

	public static void main(String[] args) {
		Environment e = new Environment(5,5,2,2);
		Agent a = new Agent(0, 0, e);
	}

}
