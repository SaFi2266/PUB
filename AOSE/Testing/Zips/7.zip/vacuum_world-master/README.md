Assignment for CS-335: Artificial Intelligence.

Artificial intelligence assignment. The agent must be able to reach every unit on the board
aside from those marked with an X. The algorithm conducts a random search in order to complete
the function.
