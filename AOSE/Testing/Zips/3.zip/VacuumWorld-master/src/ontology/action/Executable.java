package ontology.action;

import agents.Environment;

public interface Executable {
	void execute(Environment env);
}
