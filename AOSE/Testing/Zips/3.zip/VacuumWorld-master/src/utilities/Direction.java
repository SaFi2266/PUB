package utilities;

public enum Direction {
	SOUTH,
	NORTH,
	LEFT,
	RIGHT
}
